export default function Contact() {
  return (
    <section className="max-w-xl mx-auto space-y-6">
      <h2 className="text-3xl font-bold text-yellow-400">Contact Us</h2>
      <div className="bg-[#23284b] rounded-lg p-5 text-blue-100 space-y-2">
        <div>
          <b>Location:</b>
          <div>
            In front of Prof. Rajendra Singh Rajju Bhaiyya University,<br />
            Naini Industrial Area, Prayagraj - 211008
          </div>
        </div>
        <div>
          <b>Email:</b>
          <div>
            <a href="mailto:contact@hellojobs.co.in" className="text-yellow-300 hover:underline">contact@hellojobs.co.in</a>
            ,{" "}
            <a href="mailto:hjobs476@gmail.com" className="text-yellow-300 hover:underline">hjobs476@gmail.com</a>
          </div>
        </div>
        <div>
          <b>Phone:</b>
          <div>
            <a href="tel:+917007025026" className="text-yellow-300 hover:underline">7007025026</a>
            ,{" "}
            <a href="tel:+917706974608" className="text-yellow-300 hover:underline">7706974608</a>
          </div>
        </div>
        <div>
          <b>Website:</b>{" "}
          <a href="http://hellojobs.co.in" target="_blank" rel="noopener noreferrer" className="text-yellow-300 hover:underline">hellojobs.co.in</a>
        </div>
      </div>
    </section>
  );
}