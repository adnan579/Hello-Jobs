import { useEffect, useState } from "react";

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  useEffect(() => {
    fetch("http://localhost:5000/api/jobs")
      .then(res => res.json())
      .then(setJobs)
      .catch(() => setJobs([]));
  }, []);

  return (
    <section>
      <h2 className="text-3xl font-bold text-yellow-400 mb-6 text-center">Job Listings</h2>
      {jobs.length === 0 ? (
        <div className="text-blue-50 text-center">No jobs available at the moment.</div>
      ) : (
        <ul className="space-y-6">
          {jobs.map(job => (
            <li key={job.id} className="bg-[#23284b] rounded-lg p-6 shadow-md">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-xl font-semibold text-yellow-300">{job.title}</h3>
                <span className="text-blue-100">{job.company}</span>
              </div>
              <div className="text-blue-50">{job.description}</div>
              <div className="flex justify-between items-center mt-3 text-blue-200 text-sm">
                <span>{job.location}</span>
                <span>Posted: {job.postedAt}</span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}