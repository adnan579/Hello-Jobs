import { Link, NavLink } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="bg-[#1b1f36] shadow-lg">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-yellow-400 tracking-wide">
          Hello Jobs
        </Link>
        <div className="space-x-6">
          <NavLink to="/" className={({ isActive }) => isActive ? "text-yellow-400 font-semibold" : "text-white hover:text-yellow-300"}>
            Home
          </NavLink>
          <NavLink to="/jobs" className={({ isActive }) => isActive ? "text-yellow-400 font-semibold" : "text-white hover:text-yellow-300"}>
            Jobs
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => isActive ? "text-yellow-400 font-semibold" : "text-white hover:text-yellow-300"}>
            About
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => isActive ? "text-yellow-400 font-semibold" : "text-white hover:text-yellow-300"}>
            Contact
          </NavLink>
        </div>
      </div>
    </nav>
  );
}