export default function About() {
  return (
    <section className="max-w-2xl mx-auto space-y-6">
      <h2 className="text-3xl font-bold text-yellow-400">About Hello Jobs</h2>
      <p className="text-blue-50">
        <b>Mission:</b> Hello Jobs connects businesses with the right talent and empowers job seekers with meaningful opportunities. We strive to accelerate recruitment, foster growth, and build strong, capable teams tailored to industry needs.
      </p>
      <div>
        <h3 className="text-xl font-semibold text-yellow-300 mb-2">Who We Serve</h3>
        <div className="bg-[#23284b] rounded p-4 text-blue-100 mb-3">
          <b>Businesses (HR Manager Ravi):</b> Need fast, reliable hiring, quality candidates, and a simple process. We help save time and ensure you get the right fit.
        </div>
        <div className="bg-[#23284b] rounded p-4 text-blue-100">
          <b>Job Seekers (Priya, Graduate):</b> Need easy job search, relevant openings, and guidance. We simplify your journey to a meaningful career.
        </div>
      </div>
      <div>
        <h3 className="text-xl font-semibold text-yellow-300 mb-2">Differentiators</h3>
        <ul className="list-disc list-inside text-blue-100 space-y-1">
          <li>Expert consultation & personalized service</li>
          <li>Streamlined recruitment process</li>
          <li>Commitment to growth and success for all clients</li>
        </ul>
      </div>
    </section>
  );
}