export default function Home() {
  return (
    <section className="text-center space-y-6">
      <h1 className="text-4xl font-bold text-yellow-400">Welcome to Hello Jobs</h1>
      <p className="text-lg text-blue-50 max-w-xl mx-auto">
        Hello Jobs is a trusted Placement and Manpower Solutions provider dedicated to empowering businesses by connecting them with the right talent. Our expert consultation services guide organizations through seamless recruitment processes, ensuring a perfect fit for their workforce needs.
      </p>
      <div className="bg-yellow-200/90 text-[#1b1f36] font-bold py-3 rounded-md shadow-md max-w-xs mx-auto">
        🚧 Website Under Construction 🚧
      </div>
      <div className="italic text-blue-200">
        Delivering excellence in talent acquisition. Your partner in building a workforce that drives success and innovation.
      </div>
      <div className="mt-8">
        <a href="/jobs" className="bg-yellow-400 text-[#1b1f36] px-6 py-2 rounded font-semibold hover:bg-yellow-300 shadow transition">View Jobs</a>
      </div>
    </section>
  );
}